class Module4{
    String name;

    Module4(String name){
        this.name=name;
    }

    void displayModule4()
    {
        System.out.println(this.name);
    }

    public static void main(String args[]){
        Module4 c=new Module4("Welcome to Module-4 Coding test.");
        c.displayModule4();
    }
}